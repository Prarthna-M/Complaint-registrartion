// Admin Dashboard JavaScript

// Open update modal
function openUpdateModal(complaintId, currentStatus, currentRemarks) {
    const modal = document.getElementById('updateModal');
    document.getElementById('updateComplaintId').value = complaintId;
    document.getElementById('updateStatus').value = currentStatus;
    document.getElementById('updateRemarks').value = currentRemarks || '';
    modal.style.display = 'block';
}

// Close update modal
function closeModal() {
    const modal = document.getElementById('updateModal');
    modal.style.display = 'none';
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('updateModal');
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}

// Close modal with X button
document.addEventListener('DOMContentLoaded', function() {
    const closeBtn = document.querySelector('.close');
    if (closeBtn) {
        closeBtn.onclick = closeModal;
    }
    
    // Form validation
    const updateForm = document.getElementById('updateForm');
    if (updateForm) {
        updateForm.addEventListener('submit', function(e) {
            const status = document.getElementById('updateStatus').value;
            
            if (status === '') {
                alert('Please select a status');
                e.preventDefault();
                return false;
            }
        });
    }
});

// Get status class for styling
function getStatusClass(status) {
    switch(status) {
        case 'Pending':
            return 'status-pending';
        case 'In Progress':
            return 'status-in-progress';
        case 'Resolved':
            return 'status-resolved';
        default:
            return '';
    }
}

// Truncate long text
function truncateText(text, maxLength) {
    if (text.length > maxLength) {
        return text.substring(0, maxLength) + '...';
    }
    return text;
}
