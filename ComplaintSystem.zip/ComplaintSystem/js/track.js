// Track Complaint JavaScript
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('trackForm');
    
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const complaintId = document.getElementById('complaintId').value.trim();
            const complaintIdError = document.getElementById('complaintIdError');
            
            if (complaintId === '') {
                complaintIdError.textContent = 'Complaint ID is required';
                return false;
            }
            
            if (!/^CMP\d{11}$/.test(complaintId)) {
                complaintIdError.textContent = 'Invalid Complaint ID format (e.g., CMP20260206001)';
                return false;
            }
            
            complaintIdError.textContent = '';
            form.submit();
        });
    }
});

// Function to display complaint details (called from servlet response)
function displayComplaintDetails(complaint) {
    const detailsDiv = document.getElementById('complaintDetails');
    
    if (!complaint) {
        detailsDiv.innerHTML = '<p class="error">Complaint not found. Please check the Complaint ID.</p>';
        detailsDiv.style.display = 'block';
        return;
    }
    
    const statusClass = getStatusClass(complaint.status);
    
    detailsDiv.innerHTML = `
        <h3>Complaint Details</h3>
        <div class="detail-row">
            <span class="detail-label">Complaint ID:</span>
            <span class="detail-value">${complaint.complaintId}</span>
        </div>
        <div class="detail-row">
            <span class="detail-label">Name:</span>
            <span class="detail-value">${complaint.name}</span>
        </div>
        <div class="detail-row">
            <span class="detail-label">Email:</span>
            <span class="detail-value">${complaint.email}</span>
        </div>
        <div class="detail-row">
            <span class="detail-label">Category:</span>
            <span class="detail-value">${complaint.category}</span>
        </div>
        <div class="detail-row">
            <span class="detail-label">Description:</span>
            <span class="detail-value">${complaint.description}</span>
        </div>
        <div class="detail-row">
            <span class="detail-label">Status:</span>
            <span class="detail-value">
                <span class="status-badge ${statusClass}">${complaint.status}</span>
            </span>
        </div>
        <div class="detail-row">
            <span class="detail-label">Created Date:</span>
            <span class="detail-value">${complaint.createdAt}</span>
        </div>
        ${complaint.adminRemarks ? `
        <div class="detail-row">
            <span class="detail-label">Admin Remarks:</span>
            <span class="detail-value">${complaint.adminRemarks}</span>
        </div>
        ` : ''}
    `;
    
    detailsDiv.style.display = 'block';
}

function getStatusClass(status) {
    switch(status) {
        case 'Pending':
            return 'status-pending';
        case 'In Progress':
            return 'status-in-progress';
        case 'Resolved':
            return 'status-resolved';
        default:
            return '';
    }
}
