// Complaint Registration Form Validation
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('complaintForm');
    
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Clear previous errors
            clearErrors();
            
            // Validate form
            if (validateForm()) {
                // If validation passes, submit the form
                form.submit();
            }
        });
        
        // Real-time validation
        document.getElementById('name').addEventListener('blur', validateName);
        document.getElementById('email').addEventListener('blur', validateEmail);
        document.getElementById('phone').addEventListener('blur', validatePhone);
        document.getElementById('category').addEventListener('change', validateCategory);
        document.getElementById('description').addEventListener('blur', validateDescription);
    }
});

function validateForm() {
    let isValid = true;
    
    isValid = validateName() && isValid;
    isValid = validateEmail() && isValid;
    isValid = validatePhone() && isValid;
    isValid = validateCategory() && isValid;
    isValid = validateDescription() && isValid;
    
    return isValid;
}

function validateName() {
    const name = document.getElementById('name').value.trim();
    const nameError = document.getElementById('nameError');
    
    if (name === '') {
        nameError.textContent = 'Name is required';
        return false;
    }
    
    if (name.length < 3) {
        nameError.textContent = 'Name must be at least 3 characters';
        return false;
    }
    
    if (!/^[a-zA-Z\s]+$/.test(name)) {
        nameError.textContent = 'Name should contain only letters and spaces';
        return false;
    }
    
    nameError.textContent = '';
    return true;
}

function validateEmail() {
    const email = document.getElementById('email').value.trim();
    const emailError = document.getElementById('emailError');
    
    if (email === '') {
        emailError.textContent = 'Email is required';
        return false;
    }
    
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        emailError.textContent = 'Please enter a valid email address';
        return false;
    }
    
    emailError.textContent = '';
    return true;
}

function validatePhone() {
    const phone = document.getElementById('phone').value.trim();
    const phoneError = document.getElementById('phoneError');
    
    if (phone === '') {
        phoneError.textContent = 'Phone number is required';
        return false;
    }
    
    if (!/^[0-9]{10}$/.test(phone)) {
        phoneError.textContent = 'Please enter a valid 10-digit phone number';
        return false;
    }
    
    phoneError.textContent = '';
    return true;
}

function validateCategory() {
    const category = document.getElementById('category').value;
    const categoryError = document.getElementById('categoryError');
    
    if (category === '') {
        categoryError.textContent = 'Please select a complaint category';
        return false;
    }
    
    categoryError.textContent = '';
    return true;
}

function validateDescription() {
    const description = document.getElementById('description').value.trim();
    const descriptionError = document.getElementById('descriptionError');
    
    if (description === '') {
        descriptionError.textContent = 'Description is required';
        return false;
    }
    
    if (description.length < 20) {
        descriptionError.textContent = 'Description must be at least 20 characters';
        return false;
    }
    
    if (description.length > 500) {
        descriptionError.textContent = 'Description must not exceed 500 characters';
        return false;
    }
    
    descriptionError.textContent = '';
    return true;
}

function clearErrors() {
    const errors = document.querySelectorAll('.error');
    errors.forEach(error => error.textContent = '');
}
