package com.complaint.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;

import com.complaint.util.DBConnection;

/**
 * Servlet for handling complaint registration
 */
@WebServlet("/ComplaintServlet")
public class ComplaintServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    /**
     * Handle POST requests for complaint registration
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        // Get form parameters
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String category = request.getParameter("category");
        String description = request.getParameter("description");
        
        // Server-side validation
        if (name == null || name.trim().isEmpty() ||
            email == null || email.trim().isEmpty() ||
            phone == null || phone.trim().isEmpty() ||
            category == null || category.trim().isEmpty() ||
            description == null || description.trim().isEmpty()) {
            
            out.println("<html><body>");
            out.println("<h2>Error: All fields are required!</h2>");
            out.println("<a href='html/register.html'>Go Back</a>");
            out.println("</body></html>");
            return;
        }
        
        // Validate description length
        if (description.length() < 20) {
            out.println("<html><body>");
            out.println("<h2>Error: Description must be at least 20 characters!</h2>");
            out.println("<a href='html/register.html'>Go Back</a>");
            out.println("</body></html>");
            return;
        }
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        PreparedStatement userPstmt = null;
        PreparedStatement checkPstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            
            if (conn == null) {
                throw new SQLException("Failed to connect to database");
            }
            
            conn.setAutoCommit(false); // Start transaction
            
            // Check for duplicate complaint (same email, category, and description within 24 hours)
            String checkSql = "SELECT complaint_id FROM complaints WHERE email = ? " +
                            "AND category = ? AND description = ? " +
                            "AND created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)";
            checkPstmt = conn.prepareStatement(checkSql);
            checkPstmt.setString(1, email);
            checkPstmt.setString(2, category);
            checkPstmt.setString(3, description);
            rs = checkPstmt.executeQuery();
            
            if (rs.next()) {
                out.println("<html><head><link rel='stylesheet' href='css/style.css'></head><body>");
                out.println("<div class='container'><main><div class='form-container'>");
                out.println("<h2 style='color: red;'>Duplicate Complaint Detected!</h2>");
                out.println("<p>A similar complaint has already been registered recently.</p>");
                out.println("<p>Complaint ID: <strong>" + rs.getString("complaint_id") + "</strong></p>");
                out.println("<a href='html/register.html' class='btn btn-primary'>Back to Registration</a>");
                out.println("</div></main></div></body></html>");
                conn.rollback();
                return;
            }
            
            // Insert or get user
            int userId = 0;
            String userSql = "INSERT INTO users (name, email, phone) VALUES (?, ?, ?) " +
                           "ON DUPLICATE KEY UPDATE user_id=LAST_INSERT_ID(user_id)";
            userPstmt = conn.prepareStatement(userSql, PreparedStatement.RETURN_GENERATED_KEYS);
            userPstmt.setString(1, name);
            userPstmt.setString(2, email);
            userPstmt.setString(3, phone);
            userPstmt.executeUpdate();
            
            ResultSet userRs = userPstmt.getGeneratedKeys();
            if (userRs.next()) {
                userId = userRs.getInt(1);
            }
            
            // Generate unique complaint ID
            String complaintId = generateComplaintId();
            
            // Insert complaint
            String sql = "INSERT INTO complaints (complaint_id, user_id, name, email, phone, " +
                        "category, description, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending')";
            
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, complaintId);
            pstmt.setInt(2, userId);
            pstmt.setString(3, name);
            pstmt.setString(4, email);
            pstmt.setString(5, phone);
            pstmt.setString(6, category);
            pstmt.setString(7, description);
            
            int rowsAffected = pstmt.executeUpdate();
            
            conn.commit(); // Commit transaction
            
            if (rowsAffected > 0) {
                // Success page
                out.println("<html><head><link rel='stylesheet' href='css/style.css'></head><body>");
                out.println("<div class='container'><main><div class='form-container'>");
                out.println("<h2 style='color: green;'>Complaint Registered Successfully!</h2>");
                out.println("<div class='complaint-details'>");
                out.println("<div class='detail-row'>");
                out.println("<span class='detail-label'>Complaint ID:</span>");
                out.println("<span class='detail-value'><strong>" + complaintId + "</strong></span>");
                out.println("</div>");
                out.println("<div class='detail-row'>");
                out.println("<span class='detail-label'>Name:</span>");
                out.println("<span class='detail-value'>" + name + "</span>");
                out.println("</div>");
                out.println("<div class='detail-row'>");
                out.println("<span class='detail-label'>Email:</span>");
                out.println("<span class='detail-value'>" + email + "</span>");
                out.println("</div>");
                out.println("<div class='detail-row'>");
                out.println("<span class='detail-label'>Category:</span>");
                out.println("<span class='detail-value'>" + category + "</span>");
                out.println("</div>");
                out.println("<div class='detail-row'>");
                out.println("<span class='detail-label'>Status:</span>");
                out.println("<span class='detail-value'><span class='status-badge status-pending'>Pending</span></span>");
                out.println("</div>");
                out.println("</div>");
                out.println("<p>Please save your Complaint ID for tracking purposes.</p>");
                out.println("<div class='form-actions'>");
                out.println("<a href='html/track.html' class='btn btn-primary'>Track Complaint</a>");
                out.println("<a href='html/register.html' class='btn btn-secondary'>Register Another</a>");
                out.println("</div>");
                out.println("</div></main></div></body></html>");
            } else {
                throw new SQLException("Failed to register complaint");
            }
            
        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            out.println("<html><body>");
            out.println("<h2>Error: " + e.getMessage() + "</h2>");
            out.println("<a href='html/register.html'>Go Back</a>");
            out.println("</body></html>");
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (checkPstmt != null) checkPstmt.close();
                if (userPstmt != null) userPstmt.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) {
                    conn.setAutoCommit(true);
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * Generate unique complaint ID
     * Format: CMP + YYYYMMDD + 3-digit sequence number
     */
    private String generateComplaintId() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        String datePart = sdf.format(new Date());
        
        // Generate random 3-digit number
        int sequence = (int) (Math.random() * 900) + 100;
        
        return "CMP" + datePart + sequence;
    }
}
