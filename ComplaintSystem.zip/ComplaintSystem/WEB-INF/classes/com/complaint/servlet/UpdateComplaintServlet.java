package com.complaint.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;

import com.complaint.util.DBConnection;

/**
 * Servlet for updating complaint status and remarks
 */
@WebServlet("/UpdateComplaintServlet")
public class UpdateComplaintServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    /**
     * Handle POST requests for updating complaints
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Check if admin is logged in
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("adminUsername") == null) {
            response.sendRedirect("html/adminLogin.html");
            return;
        }
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String complaintId = request.getParameter("complaintId");
        String status = request.getParameter("status");
        String remarks = request.getParameter("remarks");
        
        // Server-side validation
        if (complaintId == null || complaintId.trim().isEmpty() ||
            status == null || status.trim().isEmpty()) {
            
            out.println("<html><body>");
            out.println("<h2>Error: Required fields are missing!</h2>");
            out.println("<a href='ViewComplaintsServlet'>Go Back</a>");
            out.println("</body></html>");
            return;
        }
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            conn = DBConnection.getConnection();
            
            if (conn == null) {
                throw new SQLException("Failed to connect to database");
            }
            
            String sql = "UPDATE complaints SET status = ?, admin_remarks = ?, " +
                        "updated_at = CURRENT_TIMESTAMP WHERE complaint_id = ?";
            
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, status);
            pstmt.setString(2, remarks);
            pstmt.setString(3, complaintId);
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                // Success - redirect back to dashboard
                out.println("<html><head>");
                out.println("<link rel='stylesheet' href='css/style.css'>");
                out.println("<meta http-equiv='refresh' content='2;url=ViewComplaintsServlet'>");
                out.println("</head><body>");
                out.println("<div class='container'><main><div class='form-container'>");
                out.println("<h2 style='color: green;'>Complaint Updated Successfully!</h2>");
                out.println("<p>Complaint ID: <strong>" + complaintId + "</strong></p>");
                out.println("<p>New Status: <strong>" + status + "</strong></p>");
                out.println("<p>Redirecting to dashboard...</p>");
                out.println("<a href='ViewComplaintsServlet' class='btn btn-primary'>Go to Dashboard</a>");
                out.println("</div></main></div>");
                out.println("</body></html>");
            } else {
                out.println("<html><body>");
                out.println("<h2>Error: Complaint not found!</h2>");
                out.println("<a href='ViewComplaintsServlet'>Go Back</a>");
                out.println("</body></html>");
            }
            
        } catch (SQLException e) {
            out.println("<html><body>");
            out.println("<h2>Database Error: " + e.getMessage() + "</h2>");
            out.println("<a href='ViewComplaintsServlet'>Go Back</a>");
            out.println("</body></html>");
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
