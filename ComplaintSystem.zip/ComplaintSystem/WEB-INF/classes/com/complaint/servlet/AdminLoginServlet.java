package com.complaint.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;

import com.complaint.util.DBConnection;

/**
 * Servlet for admin authentication
 */
@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    /**
     * Handle POST requests for admin login
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        // Server-side validation
        if (username == null || username.trim().isEmpty() ||
            password == null || password.trim().isEmpty()) {
            
            out.println("<html><head><link rel='stylesheet' href='css/style.css'></head><body>");
            out.println("<div class='container'><main><div class='login-container'>");
            out.println("<h2 style='color: red;'>Error!</h2>");
            out.println("<p>Username and password are required.</p>");
            out.println("<a href='html/adminLogin.html' class='btn btn-primary'>Try Again</a>");
            out.println("</div></main></div></body></html>");
            return;
        }
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            
            if (conn == null) {
                throw new SQLException("Failed to connect to database");
            }
            
            String sql = "SELECT * FROM admin WHERE username = ? AND password = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                // Login successful - create session
                HttpSession session = request.getSession();
                session.setAttribute("adminId", rs.getInt("admin_id"));
                session.setAttribute("adminUsername", rs.getString("username"));
                session.setAttribute("adminEmail", rs.getString("email"));
                session.setMaxInactiveInterval(1800); // 30 minutes
                
                // Redirect to dashboard
                response.sendRedirect("ViewComplaintsServlet");
                
            } else {
                // Login failed
                out.println("<html><head><link rel='stylesheet' href='css/style.css'></head><body>");
                out.println("<div class='container'><main><div class='login-container'>");
                out.println("<h2 style='color: red;'>Login Failed!</h2>");
                out.println("<p>Invalid username or password.</p>");
                out.println("<a href='html/adminLogin.html' class='btn btn-primary'>Try Again</a>");
                out.println("</div></main></div></body></html>");
            }
            
        } catch (SQLException e) {
            out.println("<html><body>");
            out.println("<h2>Database Error: " + e.getMessage() + "</h2>");
            out.println("<a href='html/adminLogin.html'>Go Back</a>");
            out.println("</body></html>");
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
