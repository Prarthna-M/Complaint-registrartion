package com.complaint.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;

import com.complaint.util.DBConnection;

/**
 * Servlet for tracking complaint status
 */
@WebServlet("/TrackComplaintServlet")
public class TrackComplaintServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    /**
     * Handle GET requests for tracking complaints
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String complaintId = request.getParameter("complaintId");
        
        // Validation
        if (complaintId == null || complaintId.trim().isEmpty()) {
            out.println("<html><body>");
            out.println("<h2>Error: Complaint ID is required!</h2>");
            out.println("<a href='html/track.html'>Go Back</a>");
            out.println("</body></html>");
            return;
        }
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            
            if (conn == null) {
                throw new SQLException("Failed to connect to database");
            }
            
            String sql = "SELECT * FROM complaints WHERE complaint_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, complaintId);
            
            rs = pstmt.executeQuery();
            
            out.println("<html><head>");
            out.println("<link rel='stylesheet' href='css/style.css'>");
            out.println("</head><body>");
            out.println("<div class='container'>");
            out.println("<header>");
            out.println("<h1>Online Complaint Registration System</h1>");
            out.println("<nav>");
            out.println("<a href='html/index.html'>Home</a>");
            out.println("<a href='html/register.html'>Register Complaint</a>");
            out.println("<a href='html/track.html' class='active'>Track Complaint</a>");
            out.println("<a href='html/admin-login.html'>Admin Login</a>");
            out.println("</nav></header><main>");
            
            if (rs.next()) {
                String status = rs.getString("status");
                String statusClass = getStatusClass(status);
                
                out.println("<div class='form-container'>");
                out.println("<h2>Complaint Details</h2>");
                out.println("<div class='complaint-details'>");
                
                out.println("<div class='detail-row'>");
                out.println("<span class='detail-label'>Complaint ID:</span>");
                out.println("<span class='detail-value'><strong>" + rs.getString("complaint_id") + "</strong></span>");
                out.println("</div>");
                
                out.println("<div class='detail-row'>");
                out.println("<span class='detail-label'>Name:</span>");
                out.println("<span class='detail-value'>" + rs.getString("name") + "</span>");
                out.println("</div>");
                
                out.println("<div class='detail-row'>");
                out.println("<span class='detail-label'>Email:</span>");
                out.println("<span class='detail-value'>" + rs.getString("email") + "</span>");
                out.println("</div>");
                
                out.println("<div class='detail-row'>");
                out.println("<span class='detail-label'>Phone:</span>");
                out.println("<span class='detail-value'>" + rs.getString("phone") + "</span>");
                out.println("</div>");
                
                out.println("<div class='detail-row'>");
                out.println("<span class='detail-label'>Category:</span>");
                out.println("<span class='detail-value'>" + rs.getString("category") + "</span>");
                out.println("</div>");
                
                out.println("<div class='detail-row'>");
                out.println("<span class='detail-label'>Description:</span>");
                out.println("<span class='detail-value'>" + rs.getString("description") + "</span>");
                out.println("</div>");
                
                out.println("<div class='detail-row'>");
                out.println("<span class='detail-label'>Status:</span>");
                out.println("<span class='detail-value'><span class='status-badge " + statusClass + "'>" + status + "</span></span>");
                out.println("</div>");
                
                out.println("<div class='detail-row'>");
                out.println("<span class='detail-label'>Created Date:</span>");
                out.println("<span class='detail-value'>" + rs.getTimestamp("created_at") + "</span>");
                out.println("</div>");
                
                out.println("<div class='detail-row'>");
                out.println("<span class='detail-label'>Last Updated:</span>");
                out.println("<span class='detail-value'>" + rs.getTimestamp("updated_at") + "</span>");
                out.println("</div>");
                
                String adminRemarks = rs.getString("admin_remarks");
                if (adminRemarks != null && !adminRemarks.trim().isEmpty()) {
                    out.println("<div class='detail-row'>");
                    out.println("<span class='detail-label'>Admin Remarks:</span>");
                    out.println("<span class='detail-value'>" + adminRemarks + "</span>");
                    out.println("</div>");
                }
                
                out.println("</div>");
                out.println("<div class='form-actions'>");
                out.println("<a href='html/track.html' class='btn btn-primary'>Track Another</a>");
                out.println("<a href='html/index.html' class='btn btn-secondary'>Home</a>");
                out.println("</div>");
                out.println("</div>");
                
            } else {
                out.println("<div class='form-container'>");
                out.println("<h2 style='color: red;'>Complaint Not Found!</h2>");
                out.println("<p>No complaint found with ID: <strong>" + complaintId + "</strong></p>");
                out.println("<p>Please check the Complaint ID and try again.</p>");
                out.println("<a href='html/track.html' class='btn btn-primary'>Try Again</a>");
                out.println("</div>");
            }
            
            out.println("</main>");
            out.println("<footer><p>&copy; 2026 Online Complaint System. All rights reserved.</p></footer>");
            out.println("</div></body></html>");
            
        } catch (SQLException e) {
            out.println("<html><body>");
            out.println("<h2>Database Error: " + e.getMessage() + "</h2>");
            out.println("<a href='html/track.html'>Go Back</a>");
            out.println("</body></html>");
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * Get CSS class for status badge
     */
    private String getStatusClass(String status) {
        switch(status) {
            case "Pending":
                return "status-pending";
            case "In Progress":
                return "status-in-progress";
            case "Resolved":
                return "status-resolved";
            default:
                return "";
        }
    }
}
