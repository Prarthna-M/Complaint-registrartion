package com.complaint.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;

import com.complaint.util.DBConnection;

/**
 * Servlet for viewing all complaints (Admin Dashboard)
 */
@WebServlet("/ViewComplaintsServlet")
public class ViewComplaintsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    /**
     * Handle GET requests to display complaints
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Check if admin is logged in
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("adminUsername") == null) {
            response.sendRedirect("html/adminLogin.html");
            return;
        }
        String contextPath = request.getContextPath();
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String statusFilter = request.getParameter("status");
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            conn = DBConnection.getConnection();
            
            if (conn == null) {
                throw new SQLException("Failed to connect to database");
            }
            
            // Build SQL query based on filter
            String sql;
            if (statusFilter != null && !statusFilter.equals("all")) {
                sql = "SELECT * FROM complaints WHERE status = ? ORDER BY created_at DESC";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, statusFilter);
            } else {
                sql = "SELECT * FROM complaints ORDER BY created_at DESC";
                pstmt = conn.prepareStatement(sql);
            }
            
            rs = pstmt.executeQuery();
            
            // Generate HTML page
            out.println("<!DOCTYPE html>");
            out.println("<html><head>");
            out.println("<meta charset='UTF-8'>");
            out.println("<title>Admin Dashboard</title>");
            out.println("<link rel='stylesheet' href='css/style.css'>");
            out.println("</head><body>");
            
            out.println("<div class='container'>");
            out.println("<header>");
            out.println("<h1>Admin Dashboard</h1>");
            out.println("<nav>");
            out.println("<a href='ViewComplaintsServlet' class='active'>Dashboard</a>");
            out.println("<span style='color: white; margin: 0 1rem;'>Welcome, " + session.getAttribute("adminUsername") + "</span>");
            out.println("<a href='LogoutServlet'>Logout</a>");
            out.println("</nav>");
            out.println("</header>");
            
            out.println("<main>");
            out.println("<div class='dashboard-container'>");
            out.println("<h2>Complaint Management</h2>");
            
            // Filter section
            out.println("<div class='filter-section'>");
            out.println("<form action='ViewComplaintsServlet' method='GET'>");
            out.println("<label for='statusFilter'>Filter by Status:</label>");
            out.println("<select id='statusFilter' name='status'>");
            out.println("<option value='all'" + (statusFilter == null || statusFilter.equals("all") ? " selected" : "") + ">All Complaints</option>");
            out.println("<option value='Pending'" + ("Pending".equals(statusFilter) ? " selected" : "") + ">Pending</option>");
            out.println("<option value='In Progress'" + ("In Progress".equals(statusFilter) ? " selected" : "") + ">In Progress</option>");
            out.println("<option value='Resolved'" + ("Resolved".equals(statusFilter) ? " selected" : "") + ">Resolved</option>");
            out.println("</select>");
            out.println("<button type='submit' class='btn btn-secondary'>Filter</button>");
            out.println("</form>");
            out.println("</div>");
            
            // Complaints table
            out.println("<div class='table-container'>");
            out.println("<table>");
            out.println("<thead>");
            out.println("<tr>");
            out.println("<th>Complaint ID</th>");
            out.println("<th>Name</th>");
            out.println("<th>Email</th>");
            out.println("<th>Category</th>");
            out.println("<th>Description</th>");
            out.println("<th>Status</th>");
            out.println("<th>Created Date</th>");
            out.println("<th>Action</th>");
            out.println("</tr>");
            out.println("</thead>");
            out.println("<tbody>");
            
            int count = 0;
            while (rs.next()) {
                count++;
                String complaintId = rs.getString("complaint_id");
                String status = rs.getString("status");
                String description = rs.getString("description");
                String remarks = rs.getString("admin_remarks");
                
                // Truncate long descriptions
                String shortDesc = description.length() > 50 ? 
                                 description.substring(0, 50) + "..." : description;
                
                String statusClass = getStatusClass(status);
                
                out.println("<tr>");
                out.println("<td>" + complaintId + "</td>");
                out.println("<td>" + rs.getString("name") + "</td>");
                out.println("<td>" + rs.getString("email") + "</td>");
                out.println("<td>" + rs.getString("category") + "</td>");
                out.println("<td title='" + description + "'>" + shortDesc + "</td>");
                out.println("<td><span class='status-badge " + statusClass + "'>" + status + "</span></td>");
                out.println("<td>" + rs.getTimestamp("created_at") + "</td>");
                out.println("<td>");
                out.println("<button onclick=\"openUpdateModal('" + complaintId + "', '" + 
                          status + "', '" + (remarks != null ? remarks.replace("'", "\\'") : "") + 
                          "')\">Update</button>");
                out.println("</td>");
                out.println("</tr>");
            }
            
            if (count == 0) {
                out.println("<tr><td colspan='8' style='text-align: center;'>No complaints found</td></tr>");
            }
            
            out.println("</tbody>");
            out.println("</table>");
            out.println("</div>");
            
            out.println("</div>");
            out.println("</main>");
            
            out.println("<footer><p>&copy; 2026 Online Complaint System. All rights reserved.</p></footer>");
            out.println("</div>");
            
            // Update Modal
            out.println("<div id='updateModal' class='modal'>");
            out.println("<div class='modal-content'>");
            out.println("<span class='close'>&times;</span>");
            out.println("<h2>Update Complaint Status</h2>");
            out.println("<form action='UpdateComplaintServlet' method='POST'>");
            out.println("<input type='hidden' id='updateComplaintId' name='complaintId'>");
            out.println("<div class='form-group'>");
            out.println("<label for='updateStatus'>Status <span class='required'>*</span></label>");
            out.println("<select id='updateStatus' name='status' required>");
            out.println("<option value='Pending'>Pending</option>");
            out.println("<option value='In Progress'>In Progress</option>");
            out.println("<option value='Resolved'>Resolved</option>");
            out.println("</select>");
            out.println("</div>");
            out.println("<div class='form-group'>");
            out.println("<label for='updateRemarks'>Admin Remarks</label>");
            out.println("<textarea id='updateRemarks' name='remarks' rows='4'></textarea>");
            out.println("</div>");
            out.println("<div class='form-actions'>");
            out.println("<button type='submit' class='btn btn-primary'>Update</button>");
            out.println("<button type='button' class='btn btn-secondary' onclick='closeModal()'>Cancel</button>");
            out.println("</div>");
            out.println("</form>");
            out.println("</div>");
            out.println("</div>");
            
            out.println("<script src='" + contextPath + "/js/adminDashboard.js?v=" + System.currentTimeMillis() + "'></script>");
            out.println("</body></html>");
            
        } catch (SQLException e) {
            out.println("<html><body>");
            out.println("<h2>Database Error: " + e.getMessage() + "</h2>");
            out.println("</body></html>");
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * Get CSS class for status badge
     */
    private String getStatusClass(String status) {
        switch(status) {
            case "Pending":
                return "status-pending";
            case "In Progress":
                return "status-in-progress";
            case "Resolved":
                return "status-resolved";
            default:
                return "";
        }
    }
}
